﻿namespace TicTacToe.Players;

public static class PlayerConstants
{
    public static char PlayerOneIcon = 'O';
    public static char PlayerTwoIcon = 'X';
}